
  # Clone Educate Website

  This is a code bundle for Clone Educate Website. The original project is available at https://www.figma.com/design/WE2FiSywSqaaiavdkyAMiM/Clone-Educate-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  